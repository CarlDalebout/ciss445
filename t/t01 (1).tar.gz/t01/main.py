from latextool_basic import *
test_score_table()

